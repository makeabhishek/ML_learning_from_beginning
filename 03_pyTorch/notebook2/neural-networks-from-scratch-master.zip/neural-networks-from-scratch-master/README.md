# Neural Networks From Scratch

How to build and train a neural network with just pure python (or any other language) from first principles: Math included!

Instructors: Arvind Mohan (CCS-2) and Ying Wai Li (CCS-7)

Setup on your machine
==========================
- Install Anaconda
- Clone the repository: `git@gitlab.lanl.gov:ic-user-training/neural-networks-from-scratch.git`
- Enter the directory: `cd neural-networks-from-scratch`
- Make a new conda environment: `conda create --name nn_from_scratch_tutorial`
- Activate the environment: `conda activate nn_from_scratch_tutorial`
- Install requirements available through conda: `conda install numpy jupyter jupyterlab matplotlib`
- Install Scikit Learn (This will be used only for data preprocessing - all training code will be written from scratch) 
from the instructions suitable for your platform from here https://scikit-learn.org/stable/install.html
- Launch jupyter notebook: `jupyter notebook` or jupyter lab: `jupyter lab`. Alternatively, you can use VS Code to launch the Jupyter notebooks.

Note: Please ensure you have the mnist.npz after git clone, as this is the dataset used throughout the workshop.
